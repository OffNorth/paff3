"""Couche d'accès SQLite (async, via aiosqlite)."""
import aiosqlite
from datetime import datetime, timezone
from database.models import SCHEMA


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class Database:
    def __init__(self, path: str = "memecoin_bot.db"):
        self.path = path
        self._conn: aiosqlite.Connection | None = None

    async def connect(self):
        self._conn = await aiosqlite.connect(self.path)
        await self._conn.executescript(SCHEMA)
        await self._conn.commit()

    async def close(self):
        if self._conn:
            await self._conn.close()

    # ---------- Tokens ----------
    async def upsert_token(self, market: dict):
        await self._conn.execute(
            """INSERT INTO tokens (mint, symbol, name, dex, pool_address, first_seen_at, pair_created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(mint) DO UPDATE SET symbol=excluded.symbol, name=excluded.name""",
            (market.get("mint"), market.get("symbol"), market.get("name"), market.get("dex"),
             market.get("pool_address"), now_iso(), market.get("pair_created_at")),
        )
        await self._conn.commit()

    # ---------- Snapshots (pour backtest / historique) ----------
    async def add_price_snapshot(self, market: dict):
        await self._conn.execute(
            "INSERT INTO price_snapshots (mint, ts, price_usd, market_cap, liquidity_usd) VALUES (?, ?, ?, ?, ?)",
            (market.get("mint"), now_iso(), market.get("price_usd"), market.get("market_cap"),
             market.get("liquidity_usd")),
        )
        await self._conn.commit()

    # ---------- Alertes / anti-spam ----------
    async def last_alert_for_mint(self, mint: str) -> dict | None:
        cur = await self._conn.execute(
            "SELECT total_score, sent_at FROM alerts WHERE mint=? ORDER BY id DESC LIMIT 1", (mint,)
        )
        row = await cur.fetchone()
        if not row:
            return None
        return {"total_score": row[0], "sent_at": row[1]}

    async def record_alert(self, alert: dict):
        await self._conn.execute(
            "INSERT INTO alerts (mint, symbol, level, total_score, risk_score, sent_at) VALUES (?, ?, ?, ?, ?, ?)",
            (alert.get("mint"), alert.get("symbol"), alert.get("level"),
             alert.get("total_score"), alert.get("risk_score"), now_iso()),
        )
        await self._conn.commit()

    # ---------- Calls / tracking post-alerte ----------
    async def open_call(self, mint: str, symbol: str, entry_mc: float, entry_score: float,
                         entry_features: dict | None = None, triggering_accounts: list[str] | None = None) -> int:
        import json
        cur = await self._conn.execute(
            "INSERT INTO calls (mint, symbol, entry_market_cap, entry_score, entry_features, "
            "triggering_accounts, called_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (mint, symbol, entry_mc, entry_score,
             json.dumps(entry_features) if entry_features else None,
             json.dumps(triggering_accounts) if triggering_accounts else None,
             now_iso()),
        )
        await self._conn.commit()
        return cur.lastrowid

    async def log_wallet_buy(self, label: str, address: str, mint: str):
        await self._conn.execute(
            "INSERT INTO wallet_buys (wallet_label, wallet_address, mint, detected_at) VALUES (?, ?, ?, ?)",
            (label, address, mint, now_iso()),
        )
        await self._conn.commit()

    async def has_open_call(self, mint: str) -> bool:
        cur = await self._conn.execute(
            "SELECT id FROM calls WHERE mint=? AND tracking_closed_at IS NULL", (mint,)
        )
        return (await cur.fetchone()) is not None

    async def open_calls(self) -> list[dict]:
        cur = await self._conn.execute(
            "SELECT id, mint, symbol, entry_market_cap, entry_score, called_at, peak_multiple FROM calls "
            "WHERE tracking_closed_at IS NULL"
        )
        rows = await cur.fetchall()
        cols = ["id", "mint", "symbol", "entry_market_cap", "entry_score", "called_at", "peak_multiple"]
        return [dict(zip(cols, r)) for r in rows]

    async def update_call_progress(self, call_id: int, peak_multiple: float, milestone_field: str | None,
                                    seconds_since_call: int | None):
        if milestone_field and seconds_since_call is not None:
            await self._conn.execute(
                f"UPDATE calls SET peak_multiple=?, {milestone_field}=? WHERE id=?",
                (peak_multiple, seconds_since_call, call_id),
            )
        else:
            await self._conn.execute("UPDATE calls SET peak_multiple=? WHERE id=?", (peak_multiple, call_id))
        await self._conn.commit()

    async def close_call(self, call_id: int, result: str):
        await self._conn.execute(
            "UPDATE calls SET tracking_closed_at=?, result=? WHERE id=?", (now_iso(), result, call_id)
        )
        await self._conn.commit()

    async def all_closed_calls(self) -> list[dict]:
        cur = await self._conn.execute(
            "SELECT peak_multiple, time_to_x2_seconds, time_to_x3_seconds, time_to_x5_seconds, "
            "time_to_x10_seconds, result FROM calls WHERE tracking_closed_at IS NOT NULL"
        )
        rows = await cur.fetchall()
        cols = ["peak_multiple", "time_to_x2_seconds", "time_to_x3_seconds", "time_to_x5_seconds",
                "time_to_x10_seconds", "result"]
        return [dict(zip(cols, r)) for r in rows]

    async def all_closed_calls_full(self) -> list[dict]:
        """Version complète (Phase 2) : inclut entry_market_cap, called_at, entry_features, triggering_accounts —
        utilisée par le dashboard, le pattern comparator et les stats détaillées."""
        import json
        cur = await self._conn.execute(
            "SELECT mint, symbol, entry_market_cap, entry_score, entry_features, triggering_accounts, "
            "called_at, peak_multiple, time_to_x2_seconds, time_to_x3_seconds, time_to_x5_seconds, "
            "time_to_x10_seconds, result FROM calls WHERE tracking_closed_at IS NOT NULL"
        )
        rows = await cur.fetchall()
        cols = ["mint", "symbol", "entry_market_cap", "entry_score", "entry_features", "triggering_accounts",
                "called_at", "peak_multiple", "time_to_x2_seconds", "time_to_x3_seconds", "time_to_x5_seconds",
                "time_to_x10_seconds", "result"]
        out = []
        for r in rows:
            d = dict(zip(cols, r))
            d["entry_features"] = json.loads(d["entry_features"]) if d["entry_features"] else None
            d["triggering_accounts"] = json.loads(d["triggering_accounts"]) if d["triggering_accounts"] else []
            out.append(d)
        return out

    async def all_calls_full(self) -> list[dict]:
        """Tous les calls (ouverts + fermés), pour le dashboard."""
        import json
        cur = await self._conn.execute(
            "SELECT id, mint, symbol, entry_market_cap, entry_score, triggering_accounts, called_at, "
            "peak_multiple, tracking_closed_at, result FROM calls ORDER BY id DESC LIMIT 500"
        )
        rows = await cur.fetchall()
        cols = ["id", "mint", "symbol", "entry_market_cap", "entry_score", "triggering_accounts", "called_at",
                "peak_multiple", "tracking_closed_at", "result"]
        out = []
        for r in rows:
            d = dict(zip(cols, r))
            d["triggering_accounts"] = json.loads(d["triggering_accounts"]) if d["triggering_accounts"] else []
            out.append(d)
        return out

    async def mention_counts_by_account(self, limit: int = 20) -> list[dict]:
        cur = await self._conn.execute(
            "SELECT account, COUNT(*) as cnt, AVG(weight) as avg_weight FROM mentions "
            "GROUP BY account ORDER BY cnt DESC LIMIT ?", (limit,)
        )
        rows = await cur.fetchall()
        return [{"account": r[0], "mentions": r[1], "avg_weight": round(r[2] or 0, 2)} for r in rows]
