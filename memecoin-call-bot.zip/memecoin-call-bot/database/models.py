"""Schéma SQLite. Colonnes simples et types portables pour faciliter une migration PostgreSQL future."""

SCHEMA = """
CREATE TABLE IF NOT EXISTS tokens (
    mint TEXT PRIMARY KEY,
    symbol TEXT,
    name TEXT,
    dex TEXT,
    pool_address TEXT,
    first_seen_at TEXT,
    pair_created_at INTEGER
);

CREATE TABLE IF NOT EXISTS price_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mint TEXT NOT NULL,
    ts TEXT NOT NULL,
    price_usd REAL,
    market_cap REAL,
    liquidity_usd REAL
);

CREATE TABLE IF NOT EXISTS volume_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mint TEXT NOT NULL,
    ts TEXT NOT NULL,
    volume_5m REAL,
    buys_5m INTEGER,
    sells_5m INTEGER
);

CREATE TABLE IF NOT EXISTS wallet_activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mint TEXT NOT NULL,
    ts TEXT NOT NULL,
    note TEXT
);

CREATE TABLE IF NOT EXISTS twitter_accounts (
    handle TEXT PRIMARY KEY,
    weight REAL DEFAULT 1.0
);

CREATE TABLE IF NOT EXISTS mentions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mint TEXT,
    account TEXT,
    content TEXT,
    mentioned_at TEXT,
    weight REAL DEFAULT 1.0
);

CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mint TEXT NOT NULL,
    symbol TEXT,
    level TEXT,
    total_score REAL,
    risk_score REAL,
    sent_at TEXT
);

CREATE TABLE IF NOT EXISTS calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mint TEXT NOT NULL,
    symbol TEXT,
    entry_market_cap REAL,
    entry_score REAL,
    entry_features TEXT,
    triggering_accounts TEXT,
    called_at TEXT,
    peak_multiple REAL DEFAULT 1.0,
    time_to_x2_seconds INTEGER,
    time_to_x3_seconds INTEGER,
    time_to_x5_seconds INTEGER,
    time_to_x10_seconds INTEGER,
    tracking_closed_at TEXT,
    result TEXT
);

-- Phase 2 : wallets performants suivis (définis manuellement dans tracked_wallets.json,
-- journalisés ici pour historiser leurs achats détectés)
CREATE TABLE IF NOT EXISTS wallet_buys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    wallet_label TEXT,
    wallet_address TEXT,
    mint TEXT,
    detected_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_price_snapshots_mint ON price_snapshots(mint);
CREATE INDEX IF NOT EXISTS idx_volume_snapshots_mint ON volume_snapshots(mint);
CREATE INDEX IF NOT EXISTS idx_mentions_mint ON mentions(mint);
CREATE INDEX IF NOT EXISTS idx_alerts_mint ON alerts(mint);
CREATE INDEX IF NOT EXISTS idx_calls_mint ON calls(mint);
"""
