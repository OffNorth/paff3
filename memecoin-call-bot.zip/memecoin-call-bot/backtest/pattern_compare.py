"""
Phase 2 — Compare le profil marché d'un token en cours d'évaluation aux tokens
historiques ayant réellement atteint x2/x5/x10 (calls fermés en base).

Ceci n'est PAS un modèle prédictif : c'est une similarité mesurable sur un
petit nombre de caractéristiques (âge au moment du call, ratio volume/liquidité,
ratio buyers/sellers, market cap d'entrée). Sert de signal d'appoint, jamais de
garantie — un token peut ressembler à d'anciens gagnants et ne rien faire.
"""
import statistics


FEATURES = ["age_minutes", "volume_liq_ratio", "buy_sell_ratio", "entry_market_cap"]


class PatternComparator:
    def __init__(self, db):
        self.db = db
        self._profile_cache: dict | None = None
        self._cache_ts = 0

    async def _winner_profiles(self, min_multiple: float = 3.0) -> list[dict]:
        closed = await self.db.all_closed_calls_full()
        winners = [c for c in closed if (c.get("peak_multiple") or 0) >= min_multiple and c.get("entry_features")]
        return winners

    async def similarity_score(self, current: dict, min_multiple: float = 3.0) -> float:
        """0-100 : proximité moyenne du profil courant avec les tokens gagnants passés."""
        winners = await self._winner_profiles(min_multiple)
        if len(winners) < 10:
            return 0.0  # pas assez de données historiques pour être fiable

        cur_vec = self._vectorize(current)
        sims = []
        for w in winners:
            try:
                w_vec = self._vectorize(w["entry_features"])
            except Exception:
                continue
            sims.append(self._cosine_like(cur_vec, w_vec))
        if not sims:
            return 0.0
        return round(max(0.0, min(100.0, statistics.mean(sims) * 100)), 1)

    def _vectorize(self, features: dict) -> list[float]:
        return [float(features.get(f, 0) or 0) for f in FEATURES]

    def _cosine_like(self, a: list[float], b: list[float]) -> float:
        # Normalise chaque dimension par sa valeur max des deux pour rester borné à [0,1]
        sims = []
        for x, y in zip(a, b):
            denom = max(abs(x), abs(y), 1e-9)
            sims.append(1 - abs(x - y) / denom)
        return sum(sims) / len(sims) if sims else 0.0


def extract_entry_features(market: dict, age_minutes: float | None) -> dict:
    vol = market.get("volume_5m", 0) or 0
    liq = market.get("liquidity_usd", 1) or 1
    b, s = market.get("buys_5m", 0), market.get("sells_5m", 0)
    return {
        "age_minutes": age_minutes or 0,
        "volume_liq_ratio": vol / liq,
        "buy_sell_ratio": (b / s) if s > 0 else float(b or 0),
        "entry_market_cap": market.get("market_cap", 0) or 0,
    }
