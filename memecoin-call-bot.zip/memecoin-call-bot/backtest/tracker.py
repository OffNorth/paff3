"""
Suit les tokens ayant déclenché une alerte, jusqu'à un multiple max atteint
(x2/x3/x5/x10) ou l'expiration de la fenêtre de suivi. Alimente les
statistiques de backtest (jamais utilisées comme garantie de performance future).
"""
import time
from datetime import datetime, timezone
from database.database import Database

MILESTONE_FIELDS = {2: "time_to_x2_seconds", 3: "time_to_x3_seconds", 5: "time_to_x5_seconds", 10: "time_to_x10_seconds"}


class CallTracker:
    def __init__(self, db: Database, market_aggregator, config: dict):
        self.db = db
        self.market = market_aggregator
        self.cfg = config.get("backtest", {})
        self.targets = self.cfg.get("targets", [2, 3, 5, 10])
        self.tracking_hours = self.cfg.get("tracking_duration_hours", 24)

    async def register_call(self, alert: dict, entry_features: dict | None = None,
                             triggering_accounts: list[str] | None = None):
        mint = alert["mint"]
        if await self.db.has_open_call(mint):
            return
        await self.db.open_call(
            mint, alert.get("symbol", "?"), alert.get("market_cap", 0), alert.get("total_score", 0),
            entry_features=entry_features, triggering_accounts=triggering_accounts,
        )

    async def update_all(self):
        """À appeler périodiquement (ex: toutes les 60s) pour mettre à jour les calls ouverts."""
        for call in await self.db.open_calls():
            await self._update_one(call)

    async def _update_one(self, call: dict):
        market = await self.market.fetch(call["mint"])
        called_at = datetime.fromisoformat(call["called_at"])
        elapsed = (datetime.now(timezone.utc) - called_at).total_seconds()

        if elapsed > self.tracking_hours * 3600:
            result = f"x{call['peak_multiple']:.1f} reached (tracking closed)"
            await self.db.close_call(call["id"], result)
            return

        if not market or not market.get("market_cap") or not call.get("entry_market_cap"):
            return

        multiple = market["market_cap"] / call["entry_market_cap"] if call["entry_market_cap"] else 1.0
        peak = max(call.get("peak_multiple", 1.0), multiple)

        # Détecte le premier franchissement d'un palier non encore enregistré
        milestone_field = None
        for target in sorted(self.targets):
            field = MILESTONE_FIELDS.get(target)
            if field and multiple >= target and call.get(field) is None:
                milestone_field = field
                break

        await self.db.update_call_progress(call["id"], peak, milestone_field, int(elapsed) if milestone_field else None)
