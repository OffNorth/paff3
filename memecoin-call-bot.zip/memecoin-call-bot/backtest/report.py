"""Calcule les statistiques agrégées de backtest à partir des calls fermés."""
import statistics
from collections import defaultdict
from datetime import datetime

MC_TRANCHES = [(0, 20_000, "<20K"), (20_000, 50_000, "20K-50K"), (50_000, 150_000, "50K-150K"),
               (150_000, 500_000, "150K-500K"), (500_000, float("inf"), "500K+")]


async def compute_stats(db, targets: list[int] | None = None) -> dict:
    targets = targets or [2, 3, 5, 10]
    closed = await db.all_closed_calls()
    total = len(closed)
    if total == 0:
        return {"total_calls": 0}

    peaks = [c["peak_multiple"] for c in closed if c["peak_multiple"] is not None]
    stats = {"total_calls": total}

    for t in targets:
        field = f"time_to_x{t}_seconds"
        reached = [c for c in closed if c.get(field) is not None]
        stats[f"calls_reaching_x{t}"] = len(reached)
        stats[f"pct_reaching_x{t}"] = round(len(reached) / total * 100, 1)
        if reached:
            avg_time = statistics.mean(c[field] for c in reached) / 60
            stats[f"avg_time_to_x{t}_min"] = round(avg_time, 1)

    if peaks:
        stats["avg_max_multiple"] = round(statistics.mean(peaks), 2)
        stats["median_max_multiple"] = round(statistics.median(peaks), 2)

    return stats


async def compute_stats_by_mc_tranche(db) -> list[dict]:
    """Phase 2 — % de calls réussis (peak >= x2) par tranche de market cap d'entrée."""
    closed = await db.all_closed_calls_full()
    out = []
    for lo, hi, label in MC_TRANCHES:
        group = [c for c in closed if lo <= (c.get("entry_market_cap") or 0) < hi]
        if not group:
            out.append({"tranche": label, "total": 0})
            continue
        success = [c for c in group if (c.get("peak_multiple") or 0) >= 2]
        out.append({
            "tranche": label,
            "total": len(group),
            "pct_reaching_x2": round(len(success) / len(group) * 100, 1),
            "avg_max_multiple": round(statistics.mean(c["peak_multiple"] for c in group), 2),
        })
    return out


async def compute_stats_by_hour(db) -> list[dict]:
    """Phase 2 — % de calls réussis par heure de la journée (UTC) du call."""
    closed = await db.all_closed_calls_full()
    by_hour = defaultdict(list)
    for c in closed:
        try:
            hour = datetime.fromisoformat(c["called_at"]).hour
        except Exception:
            continue
        by_hour[hour].append(c)
    out = []
    for hour in sorted(by_hour):
        group = by_hour[hour]
        success = [c for c in group if (c.get("peak_multiple") or 0) >= 2]
        out.append({
            "hour_utc": hour,
            "total": len(group),
            "pct_reaching_x2": round(len(success) / len(group) * 100, 1) if group else 0,
        })
    return out


async def compute_stats_by_account(db, limit: int = 20) -> list[dict]:
    """Phase 2 — volume de mentions par compte X suivi (nécessite le volet X/Twitter actif)."""
    return await db.mention_counts_by_account(limit)
