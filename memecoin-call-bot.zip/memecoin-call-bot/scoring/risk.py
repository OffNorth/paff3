"""Risk engine : détecte des signaux de risque mesurables (pas une détection de scam garantie)."""
import time


class RiskEngine:
    def __init__(self, flags: dict):
        self.flags = flags

    def assess(self, market: dict) -> dict:
        risk = 0
        flags = []

        liq = market.get("liquidity_usd", 0)
        if liq < self.flags["low_liquidity_usd"]:
            risk += 30
            flags.append("Low liquidity")

        age = self._age_min(market.get("pair_created_at"))
        if age is not None and age < self.flags["very_new_token_minutes"]:
            risk += 25
            flags.append("Very new token")

        v5 = market.get("volume_5m", 0)
        if liq > 0 and v5 / liq > self.flags["suspicious_volume_ratio"]:
            risk += 20
            flags.append("Suspicious volume (possible wash trading)")

        b, s = market.get("buys_5m", 0), market.get("sells_5m", 0)
        t = b + s
        if t > 20:
            r = b / t
            if r > 0.95 or r < 0.05:
                risk += 15
                flags.append("Abnormal buy/sell ratio")

        holders = market.get("holders")
        if holders is not None and holders < 20 and age is not None and age > 5:
            risk += 10
            flags.append("Very few holders for token age")

        # Signaux on-chain (rug_check.py) : les plus fiables, donc les plus lourds
        if market.get("mint_authority_active"):
            risk += 40
            flags.append("Mint authority active (supply modifiable par le dev)")
        if market.get("freeze_authority_active"):
            risk += 35
            flags.append("Freeze authority active (wallets gelables par le dev)")
        top_pct = market.get("top_holder_pct_excl_lp")
        if top_pct is not None and top_pct > self.flags.get("high_holder_concentration_pct", 80):
            risk += 20
            flags.append(f"Concentration holder très élevée hors LP: {top_pct:.0f}%")
        elif top_pct is not None and top_pct > 30:
            risk += 10
            flags.append(f"Concentration holder élevée hors LP: {top_pct:.0f}%")

        if not flags:
            flags.append("Aucun flag détecté (ne garantit pas l'absence de risque)")

        return {"risk_score": min(risk, 100), "risk_flags": flags}

    def _age_min(self, created_ms):
        if not created_ms:
            return None
        return (time.time() * 1000 - created_ms) / 60000
