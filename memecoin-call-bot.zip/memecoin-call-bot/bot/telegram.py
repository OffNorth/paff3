"""Interface Telegram : commandes, callbacks, envoi d'alertes."""
import logging
from telegram import Update
from telegram.error import TimedOut, NetworkError
from telegram.ext import Application, CommandHandler, ContextTypes, CallbackQueryHandler
from bot.alerts import build_keyboard, format_alert

logger = logging.getLogger(__name__)


class TelegramBot:
    def __init__(self, token: str, chat_id: str, config: dict, stats_provider=None):
        self.token = token
        self.chat_id = chat_id
        self.config = config
        self.stats_provider = stats_provider  # callable -> dict (pour /status, /stats)
        self.app: Application | None = None

    def build_app(self) -> Application:
        app = (
            Application.builder()
            .token(self.token)
            .connect_timeout(20)
            .read_timeout(20)
            .write_timeout(20)
            .pool_timeout(20)
            .get_updates_connect_timeout(20)
            .get_updates_read_timeout(40)
            .build()
        )
        app.add_handler(CommandHandler("start", self._start))
        app.add_handler(CommandHandler("status", self._status))
        app.add_handler(CommandHandler("stats", self._stats))
        app.add_handler(CommandHandler("config", self._show_config))
        app.add_handler(CallbackQueryHandler(self._button))
        app.add_error_handler(self._on_error)
        self.app = app
        return app

    async def _on_error(self, update: object, ctx: ContextTypes.DEFAULT_TYPE):
        err = ctx.error
        if isinstance(err, (TimedOut, NetworkError)):
            # Micro-coupure réseau ponctuelle : le bot continue de tourner normalement,
            # inutile de logger une trace complète à chaque fois.
            logger.warning(f"Réseau temporairement indisponible ({type(err).__name__}), le bot continue.")
            return
        logger.error(f"Erreur non gérée: {err}", exc_info=err)

    async def _start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(
            "🤖 Solana Memecoin X2/X3 Call Bot\n\n"
            "Commandes :\n"
            "/status — état du scanner\n"
            "/stats — statistiques de backtest\n"
            "/config — seuils et poids actuels\n\n"
            "⚠️ Ce bot ne prédit rien. Il calcule un score de probabilité basé sur des données mesurables."
        )

    async def _status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text("🟢 Scanner actif.")

    async def _stats(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self.stats_provider:
            await update.message.reply_text("Pas de statistiques disponibles pour le moment.")
            return
        stats = await self.stats_provider()
        lines = ["📈 <b>Statistiques (backtest)</b>", ""]
        for k, v in stats.items():
            lines.append(f"{k}: {v}")
        await update.message.reply_text("\n".join(lines), parse_mode="HTML")

    async def _show_config(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        th = self.config.get("alert_thresholds", {})
        w = self.config.get("score_weights", {})
        text = (
            "⚙️ <b>Configuration actuelle</b>\n\n"
            f"Seuils: WATCH≥{th.get('watch')} POTENTIAL≥{th.get('potential')} STRONG≥{th.get('strong')}\n\n"
            "Poids du score:\n" + "\n".join(f"- {k}: {v}" for k, v in w.items())
        )
        await update.message.reply_text(text, parse_mode="HTML")

    async def _button(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        q = update.callback_query
        await q.answer()
        if q.data.startswith("copy:"):
            mint = q.data.split(":", 1)[1]
            await q.message.reply_text(f"<code>{mint}</code>", parse_mode="HTML")

    async def send_alert(self, alert: dict):
        text = format_alert(alert)
        try:
            await self.app.bot.send_message(
                chat_id=self.chat_id,
                text=text,
                parse_mode="HTML",
                reply_markup=build_keyboard(alert["mint"]),
                disable_web_page_preview=True,
            )
        except Exception as e:
            logger.error(f"Erreur envoi alerte Telegram: {e}")
