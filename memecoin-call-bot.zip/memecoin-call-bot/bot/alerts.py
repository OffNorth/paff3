"""Construction des messages d'alerte Telegram et des claviers inline."""
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

LEVEL_EMOJI = {"WATCH": "🟡", "POTENTIAL": "🟢", "STRONG": "🔥"}
LEVEL_LABEL = {"WATCH": "WATCH", "POTENTIAL": "POTENTIAL X2+", "STRONG": "STRONG SIGNAL"}


def build_keyboard(mint: str) -> InlineKeyboardMarkup:
    kb = [
        [
            InlineKeyboardButton("📊 Chart", url=f"https://dexscreener.com/solana/{mint}"),
            InlineKeyboardButton("🪙 DexScreener", url=f"https://dexscreener.com/solana/{mint}"),
        ],
        [
            InlineKeyboardButton("🚀 Pump.fun", url=f"https://pump.fun/coin/{mint}"),
            InlineKeyboardButton("🔎 Solscan", url=f"https://solscan.io/token/{mint}"),
        ],
        [InlineKeyboardButton("📋 Copy Mint", callback_data=f"copy:{mint}")],
    ]
    return InlineKeyboardMarkup(kb)


def format_alert(a: dict) -> str:
    level = a.get("level", "WATCH")
    emoji = LEVEL_EMOJI.get(level, "🟡")
    label = LEVEL_LABEL.get(level, level)
    risk_flags = a.get("risk_flags") or ["Aucun flag détecté"]
    risk_text = "\n".join(f"- {f}" for f in risk_flags)
    mc = a.get("market_cap", 0) or 0
    age = a.get("age_minutes")
    age_str = f"{age:.1f}" if age is not None else "?"
    holder_growth = a.get("holder_growth_pct")
    holder_line = f"👥 Holders: {holder_growth:+.0f}% / 10 min\n" if holder_growth is not None else ""

    smart_wallets = a.get("smart_wallets_buying") or []
    smart_wallet_line = f"🧠 Smart wallets: {', '.join(smart_wallets)}\n" if smart_wallets else ""

    phase2_lines = []
    if a.get("pattern_similarity") is not None:
        phase2_lines.append(f"🔁 Similarité vs winners passés: {a['pattern_similarity']:.0f}/100")
    if a.get("ml_success_probability") is not None:
        phase2_lines.append(f"🎲 Modèle ML (proba x2+): {a['ml_success_probability']:.0f}%")
    phase2_block = ("\n" + "\n".join(phase2_lines) + "\n") if phase2_lines else ""

    return f"""🚨 {emoji} {label} {emoji} 🚨

<b>${a.get('symbol', '???')}</b>

📊 Market Cap: ${mc:,.0f}
💧 Liquidity: ${a.get('liquidity_usd', 0):,.0f}
⏱ Age: {age_str} min

📈 Price: {a.get('price_change_5m', 0):+.1f}% 5m
💰 Volume: ${a.get('volume_5m', 0):,.0f} 5m

🟢 Buyers: {a.get('buys_5m', 0)}
🔴 Sellers: {a.get('sells_5m', 0)}
{holder_line}{smart_wallet_line}
🐦 X Momentum: {a.get('social_score', 0):.0f}/100
📈 Social acceleration: {a.get('social_acceleration', 0):.0f}/100
{phase2_block}
🧠 <b>TOTAL SCORE: {a.get('total_score', 0):.0f}/100</b>
🛡 RISK SCORE: {a.get('risk_score', 0):.0f}/100

🎯 Reference levels:
X2 → ${mc * 2:,.0f} MC
X3 → ${mc * 3:,.0f} MC
X5 → ${mc * 5:,.0f} MC
X10 → ${mc * 10:,.0f} MC

⚠️ Risk flags:
{risk_text}

Mint:
<code>{a.get('mint', '')}</code>

⚠️ Ceci n'est PAS un conseil financier. Score de probabilité, pas une certitude."""
