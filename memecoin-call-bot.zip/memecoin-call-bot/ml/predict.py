"""Charge ml/model.json (si présent) et calcule une probabilité de succès pour un token."""
import json
import math
import os
from backtest.pattern_compare import FEATURES


class MLPredictor:
    def __init__(self, model_path: str = "ml/model.json"):
        self.model = None
        if os.path.exists(model_path):
            with open(model_path, "r", encoding="utf-8") as f:
                self.model = json.load(f)

    @property
    def available(self) -> bool:
        return self.model is not None

    def predict_proba(self, features: dict) -> float | None:
        if not self.model:
            return None
        weights = self.model["weights"]
        mins, maxs = self.model["mins"], self.model["maxs"]
        x = [float(features.get(f, 0) or 0) for f in FEATURES]
        x_norm = [(xi - mn) / ((mx - mn) or 1.0) for xi, mn, mx in zip(x, mins, maxs)]
        z = weights[0] + sum(w * xi for w, xi in zip(weights[1:], x_norm))
        z = max(-30, min(30, z))
        return 1 / (1 + math.exp(-z))
