"""Extraction des signaux (cashtags, adresses mint, liens) depuis un texte de post X."""
import re

CASHTAG_RE = re.compile(r"\$([A-Za-z0-9_]{2,15})")
# Adresses Solana : base58, 32-44 caractères (approximation robuste en pratique)
MINT_RE = re.compile(r"\b[1-9A-HJ-NP-Za-km-z]{32,44}\b")
DEX_RE = re.compile(r"dexscreener\.com/solana/([1-9A-HJ-NP-Za-km-z]{32,44})")
PUMP_RE = re.compile(r"pump\.fun/(?:coin/)?([1-9A-HJ-NP-Za-km-z]{32,44})")


def extract_signals(text: str) -> dict:
    text = text or ""
    cashtags = [c.upper() for c in CASHTAG_RE.findall(text)]
    mints = set(MINT_RE.findall(text))
    mints.update(DEX_RE.findall(text))
    mints.update(PUMP_RE.findall(text))
    return {
        "cashtags": cashtags,
        "mints": list(mints),
    }


def matches_token(text: str, symbol: str | None, mint: str | None) -> bool:
    """Vérifie si un post mentionne vraiment CE token précis (par mint de préférence,
    car plusieurs tokens peuvent partager le même ticker — voir risque de faux positifs)."""
    signals = extract_signals(text)
    if mint and mint in signals["mints"]:
        return True
    if symbol and symbol.upper() in signals["cashtags"]:
        # Match par ticker seul : signal plus faible (faux positifs possibles),
        # à combiner avec d'autres critères en amont si besoin.
        return True
    return False
