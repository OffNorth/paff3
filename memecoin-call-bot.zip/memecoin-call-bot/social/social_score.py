"""Calcule le score de social momentum (volume + accélération des mentions)."""
import time
from datetime import datetime


class SocialScorer:
    def __init__(self, config: dict):
        self.cfg = config

    def compute(self, mentions: list[dict]) -> dict:
        now = time.time()

        def in_window(seconds: int) -> list[dict]:
            cutoff = now - seconds
            return [m for m in mentions if self._ts(m) >= cutoff]

        w5, w15, w60 = in_window(300), in_window(900), in_window(3600)

        def weighted(lst):
            return sum(m.get("weight", 1.0) for m in lst)

        c5, c60 = weighted(w5), weighted(w60)
        uniq5 = len(set(m.get("account") for m in w5))

        rate5 = c5 / 5
        rate60 = c60 / 60
        accel_ratio = (rate5 / rate60) if rate60 > 0 else (1.0 if rate5 > 0 else 0)

        # Volume brut de mentions récentes + diversité des comptes
        social_score = min(100, c5 * 10 + uniq5 * 5)
        # Accélération : ce qui compte vraiment est 0->2->8->30, pas 100->105
        accel_score = min(100, max(0, (accel_ratio - 1) * 50))

        return {
            "social_score": round(social_score, 1),
            "social_acceleration": round(accel_score, 1),
            "mentions_5m": len(w5),
            "mentions_15m": len(w15),
            "mentions_60m": len(w60),
            "unique_accounts_5m": uniq5,
        }

    def _ts(self, m: dict) -> float:
        try:
            dt = m.get("mentioned_at")
            if isinstance(dt, str):
                return datetime.fromisoformat(dt.replace("Z", "+00:00")).timestamp()
            if hasattr(dt, "timestamp"):
                return dt.timestamp()
        except Exception:
            pass
        return 0
