"""
Vérifications anti-rug on-chain, gratuites, via le RPC Solana public
(getAccountInfo, getTokenLargestAccounts, getTokenAccountsByOwner).

Ce module ne détecte PAS tous les rugs possibles (un dev peut toujours
vendre massivement, retirer la liquidité après coup, ou avoir un contrat
malveillant plus subtil). Il couvre les trois signaux les plus fiables et
les plus fréquents sur les memecoins Solana :

1. Mint authority active  -> le créateur peut fabriquer des tokens à volonté
2. Freeze authority active -> le créateur peut geler n'importe quel wallet
3. Concentration excessive d'un wallet hors pool de liquidité

⚠️ Un token qui passe ces trois checks n'est PAS "sûr" pour autant — ce
sont des conditions nécessaires, pas suffisantes.
"""
import aiohttp
from typing import Optional

BURN_ADDRESSES = {
    "11111111111111111111111111111111",
    "1nc1nerator11111111111111111111111111111",
}


class RugChecker:
    def __init__(self, session: aiohttp.ClientSession, rpc_url: str):
        self.session = session
        self.rpc_url = rpc_url
        self._cache: dict[str, dict] = {}

    async def _rpc(self, method: str, params: list) -> Optional[dict]:
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        try:
            async with self.session.post(self.rpc_url, json=payload, timeout=10) as r:
                if r.status == 200:
                    data = await r.json()
                    return data.get("result")
        except Exception:
            return None
        return None

    async def _mint_authorities(self, mint: str) -> Optional[dict]:
        result = await self._rpc("getAccountInfo", [mint, {"encoding": "jsonParsed"}])
        try:
            info = result["value"]["data"]["parsed"]["info"]
            return {
                "mint_authority": info.get("mintAuthority"),
                "freeze_authority": info.get("freezeAuthority"),
                "supply": int(info.get("supply", 0)),
                "decimals": info.get("decimals", 0),
            }
        except (TypeError, KeyError):
            return None

    async def _lp_token_account(self, mint: str, pool_address: str) -> Optional[str]:
        if not pool_address:
            return None
        result = await self._rpc(
            "getTokenAccountsByOwner",
            [pool_address, {"mint": mint}, {"encoding": "jsonParsed"}],
        )
        try:
            accounts = result["value"]
            if accounts:
                return accounts[0]["pubkey"]
        except (TypeError, KeyError, IndexError):
            return None
        return None

    async def _top_holder_pct_excl_lp(self, mint: str, pool_address: str, supply: int, decimals: int) -> Optional[float]:
        result = await self._rpc("getTokenLargestAccounts", [mint])
        try:
            accounts = result["value"]
        except (TypeError, KeyError):
            return None
        if not accounts or supply <= 0:
            return None

        lp_account = await self._lp_token_account(mint, pool_address)
        for acc in accounts:
            if acc.get("address") == lp_account:
                continue
            amount = int(acc.get("amount", 0))
            return round(amount / supply * 100, 1)
        return None

    async def check(self, mint: str, pool_address: str | None) -> dict:
        """Retourne un dict de flags + un indicateur hard_block (rug quasi-certain)."""
        if mint in self._cache:
            return self._cache[mint]

        out = {
            "mint_authority_active": None,
            "freeze_authority_active": None,
            "top_holder_pct_excl_lp": None,
            "hard_block": False,
            "rug_flags": [],
            "rug_check_available": False,
        }

        mint_info = await self._mint_authorities(mint)
        if mint_info:
            out["rug_check_available"] = True
            out["mint_authority_active"] = mint_info["mint_authority"] is not None
            out["freeze_authority_active"] = mint_info["freeze_authority"] is not None
            if out["mint_authority_active"]:
                out["rug_flags"].append("Mint authority active (supply modifiable par le dev)")
            if out["freeze_authority_active"]:
                out["rug_flags"].append("Freeze authority active (wallets gelables par le dev)")

            top_pct = await self._top_holder_pct_excl_lp(
                mint, pool_address or "", mint_info["supply"], mint_info["decimals"]
            )
            out["top_holder_pct_excl_lp"] = top_pct
            if top_pct is not None and top_pct > 30:
                out["rug_flags"].append(f"Concentration holder élevée hors LP: {top_pct:.0f}% dans un seul wallet")

        self._cache[mint] = out
        return out


class NullRugChecker:
    async def check(self, mint: str, pool_address: str | None) -> dict:
        return {
            "mint_authority_active": None, "freeze_authority_active": None,
            "top_holder_pct_excl_lp": None, "hard_block": False, "rug_flags": [],
            "rug_check_available": False,
        }
