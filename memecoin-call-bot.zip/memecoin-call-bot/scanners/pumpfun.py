"""
Pump.fun n'expose pas d'API publique documentée/stable.
Stratégie V1 : découverte indirecte via DexScreener (paires taguées pump.fun)
et via les tokens récemment boostés. Cette approche évite de contourner
une quelconque protection du site.
"""


async def discover_pumpfun_tokens(dex_scanner, limit: int = 20) -> list[str]:
    results = await dex_scanner.search_pairs("pump")
    mints = []
    for p in results:
        if p.get("chainId") != "solana":
            continue
        if p.get("dexId") not in ("pumpfun", "pumpswap"):
            continue
        addr = p.get("baseToken", {}).get("address")
        if addr and addr not in mints:
            mints.append(addr)
        if len(mints) >= limit:
            break
    return mints


async def discover_boosted_tokens(dex_scanner, limit: int = 20) -> list[str]:
    boosted = await dex_scanner.boosted_tokens()
    mints = []
    for b in boosted:
        if b.get("chainId") != "solana":
            continue
        addr = b.get("tokenAddress")
        if addr and addr not in mints:
            mints.append(addr)
        if len(mints) >= limit:
            break
    return mints
