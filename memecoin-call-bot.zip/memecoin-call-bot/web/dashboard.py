"""
Phase 2 — Dashboard web léger (aiohttp, aucune dépendance supplémentaire).
Sert une page HTML (Chart.js via CDN) + un endpoint JSON /api/stats consommé
par la page. Lancé en tâche de fond par main.py si config["dashboard"]["enabled"].

Accès par défaut : http://127.0.0.1:8080 (ou l'IP de la machine sur le réseau local).
"""
import json
from aiohttp import web

from backtest.report import compute_stats, compute_stats_by_mc_tranche, compute_stats_by_hour, compute_stats_by_account


def create_app(db, config: dict) -> web.Application:
    app = web.Application()

    async def index(request):
        return web.FileResponse(path="web/templates/index.html")

    async def api_stats(request):
        targets = config.get("backtest", {}).get("targets")
        overall = await compute_stats(db, targets)
        by_mc = await compute_stats_by_mc_tranche(db)
        by_hour = await compute_stats_by_hour(db)
        by_account = await compute_stats_by_account(db)
        calls = await db.all_calls_full()
        return web.json_response({
            "overall": overall,
            "by_mc_tranche": by_mc,
            "by_hour": by_hour,
            "by_account": by_account,
            "recent_calls": calls[:50],
        })

    app.router.add_get("/", index)
    app.router.add_get("/api/stats", api_stats)
    app.router.add_static("/static", path="web/static", name="static")
    return app


async def run_dashboard(db, config: dict):
    host = config.get("dashboard", {}).get("host", "127.0.0.1")
    port = config.get("dashboard", {}).get("port", 8080)
    app = create_app(db, config)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host, port)
    await site.start()
    print(f"📊 Dashboard disponible sur http://{host}:{port}")
    # Garde la tâche vivante indéfiniment
    import asyncio
    while True:
        await asyncio.sleep(3600)
